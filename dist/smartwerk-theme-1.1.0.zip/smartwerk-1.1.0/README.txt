SmartWerk WordPress Theme 1.1.0
================================

Eigenständiges SmartWerk-Theme auf Basis des bestätigten GitHub-Masters.
Kein Kiosko-Child-Theme.

Enthalten
---------
- vollständiger aktueller SmartWerk-Master-CSS-Stand
- zentraler SmartWerk Header und Footer
- korrekte WordPress-Menüstruktur
- responsive Desktop/Tablet/Mobile-Navigation
- WooCommerce Theme Support
- WooCommerce Classic + WooCommerce Blocks Grundintegration
- echter WooCommerce Warenkorb-Link und dynamischer Artikelzähler
- Gutenberg/WordPress Seiteninhalte bleiben bearbeitbar
- Übergangsschutz gegen alte eingebettete sw-header/sw-footer
- WP3DPrinting wird nur außen eingebettet; keine geratenen Plugin-internen CSS-Hacks
- Wissen-&-STL-Mobile-Accordions

WP3DPrinting
------------
Bestehender SmartWerk-Shortcode:
[3dprint product_id="783" mode="single" compatibility_mode="true"]

Wichtig
-------
Das Theme enthält die Darstellungs- und Integrationsschicht. Die alten
WordPress-Seiteninhalte müssen anschließend mit Easy MCP AI/WPWriter auf den
neuen GitHub-Master-Inhalt migriert werden. Das Theme löscht keine Inhalte.

Die alten page-level SmartWerk Header/Footer werden während der Übergangsphase
nur ausgeblendet, damit der neue globale Theme-Header/Footer nicht doppelt
erscheint.

Installation
------------
1. WordPress > Design > Themes > Theme hinzufügen > Theme hochladen
2. smartwerk-theme-1.1.0.zip auswählen
3. Installieren
4. Vor der Live-Aktivierung in Preview/Staging prüfen
5. Hauptnavigation dem Theme-Ort "Hauptnavigation" zuweisen
6. WooCommerce und WP3DPrinting aktiv lassen

Hinweis zu Schriftarten
-----------------------
Der bestätigte Master verwendet derzeit Manrope über Google Fonts. Diese
Referenz wurde für visuelle Gleichheit unverändert übernommen. Vor dem
endgültigen Livegang kann die Schrift datenschutzorientiert lokalisiert oder
durch einen System-Font-Stack ersetzt werden.
